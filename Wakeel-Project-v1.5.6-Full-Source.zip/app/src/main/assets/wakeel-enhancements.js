/* Wakeel v1.5.6 — service routing and local task manager.
   Local-only features are deliberately labelled; no payment or background notification is claimed. */
(() => {
  "use strict";

  const $ = (selector, scope = document) => scope.querySelector(selector);
  const normalize = (value) => String(value || "")
    .toLowerCase()
    .replace(/[\u064B-\u065F\u0670\u0640]/g, "")
    .replace(/[أإآٱ]/g, "ا")
    .replace(/ى/g, "ي")
    .replace(/ة/g, "ه")
    .replace(/\s+/g, " ")
    .trim();

  const originalToast = window.toast;
  const originalAdd = window.add;
  const originalView = window.view;

  function notify(message) {
    if (typeof originalToast === "function") originalToast(message);
  }

  function showChat() {
    if (typeof originalView === "function") originalView("chat");
  }

  function addMessage(message) {
    if (typeof originalAdd === "function") originalAdd("ai", message);
  }

  function addActionCard(message, label, href) {
    const messages = $("#messages");
    if (!messages) {
      addMessage(message);
      return;
    }
    const card = document.createElement("div");
    card.className = "message ai wakeel-action-card";
    const paragraph = document.createElement("p");
    paragraph.textContent = message;
    const link = document.createElement("a");
    link.className = "wakeel-action-link";
    link.textContent = label;
    link.href = href;
    link.rel = "noopener noreferrer";
    card.append(paragraph, link);
    messages.appendChild(card);
    const content = $(".content");
    if (content) content.scrollTop = content.scrollHeight;
  }

  function showResult(message) {
    showChat();
    addMessage(message);
  }

  const routes = [
    {
      id: "pharmacy", terms: ["صيدليه", "صيدلية", "اقرب صيدليه", "دواء من صيدليه"],
      title: "البحث عن صيدلية قريبة",
      message: "سأفتح تطبيق الخرائط للبحث عن الصيدليات القريبة. تحقق من العنوان وساعات العمل قبل التوجه.",
      map: "pharmacy"
    },
    {
      id: "hospital", terms: ["مستشفي", "مستشفى", "اقرب مستشفي", "طوارئ"],
      title: "البحث عن مستشفى",
      message: "سأفتح الخرائط للبحث عن المستشفيات القريبة. في حالة الطوارئ اتصل بخدمات الطوارئ المحلية مباشرة.",
      map: "hospital"
    },
    {
      id: "doctor", terms: ["طبيب", "دكتور", "عياده", "عيادة", "كشف طبي"],
      title: "البحث عن طبيب",
      message: "يمكنك البحث عن الأطباء والعيادات القريبة عبر الخرائط، ثم التواصل مع الجهة مباشرة للتأكد من التخصص والمواعيد.",
      map: "doctors"
    },
    {
      id: "atm", terms: ["atm", "ماكينه صراف", "ماكينة صراف", "صراف الي", "صراف آلي", "اقرب atm"],
      title: "البحث عن ماكينة صراف آلي",
      message: "سأفتح الخرائط للبحث عن ماكينات الصراف القريبة. راجع اسم البنك وموقع الماكينة قبل الذهاب.",
      map: "ATM"
    },
    {
      id: "fuel", terms: ["بنزين", "محطه وقود", "محطة وقود", "اقرب بنزين"],
      title: "البحث عن محطة وقود",
      message: "سأفتح الخرائط للبحث عن محطات الوقود القريبة.",
      map: "محطة وقود"
    },
    {
      id: "restaurant", terms: ["مطعم", "مطاعم", "اكل قريب", "مطاعم قريبه"],
      title: "البحث عن مطاعم",
      message: "سأفتح الخرائط للبحث عن المطاعم القريبة.",
      map: "مطاعم"
    }
  ];

  function routeRequest(rawText) {
    const raw = String(rawText || "").trim();
    const text = normalize(raw);
    if (!text) return true;

    if (/(ذكرني|تذكير|مهمه|مهمة|موعد الدواء|مواعيد الدواء)/.test(text)) {
      if (typeof originalView === "function") originalView("tasks");
      setTimeout(() => {
        const title = $("#wakeelTaskTitle");
        if (title) {
          title.value = raw.includes("ذكرني") ? raw.replace(/^.*?(ذكرني|تذكير)\s*/i, "").trim() : "";
          title.focus();
        }
      }, 80);
      notify("أضف تفاصيل التذكير وموعده في قسم المهام. التنبيه هنا داخل التطبيق فقط.");
      return true;
    }

    if (/(الساعه|الساعة|الصحه|الصحة|صحي|صحيه|صحية|health connect|البيانات الصحيه)/.test(text)) {
      if (typeof originalView === "function") originalView("health");
      return true;
    }

    if (/(مخالفات المرور|مخالفات|المرور|نيابه|النيابة)/.test(text)) {
      addActionCard(
        "يمكنك متابعة خدمات النيابة العامة من بوابتها الرسمية. سيغادر الرابط تطبيق وكيلك، ولا ينفذ وكيلك السداد أو المعاملة بنفسه.",
        "فتح بوابة النيابة العامة",
        "https://ppo.gov.eg/"
      );
      return true;
    }

    if (/(مصر الرقميه|مصر الرقمية|خدمات حكوميه|خدمات حكومية|بطاقه الرقم القومي|بطاقة الرقم القومي|تموين|شهر عقاري)/.test(text)) {
      addActionCard(
        "للوصول إلى الخدمات الحكومية الرقمية استخدم البوابة الرسمية. تسجيل الدخول وإتمام المعاملة يتمان لدى الجهة الحكومية نفسها.",
        "فتح منصة مصر الرقمية",
        "https://digital.gov.eg/"
      );
      return true;
    }

    if (/(كهرباء|فاتوره الكهرباء|فاتورة الكهرباء|مياه|فاتوره المياه|فاتورة المياه|غاز|فاتوره الغاز|فاتورة الغاز|ادفع فاتوره)/.test(text)) {
      showResult("وكيلك لا يستقبل أرقام العدادات أو بيانات الدفع ولا ينفذ السداد في هذه النسخة. افتح تطبيق شركة المرافق أو قناة الدفع الرسمية الموجودة على فاتورتك، وتأكد من اسم الجهة قبل الدفع.");
      return true;
    }

    if (/(شحن رصيد|رصيد الموبايل|باقه|باقة|انترنت|إنترنت|اتصالات|فودافون|اورنج|أورنج|وي|اتصالات مصر)/.test(text)) {
      showResult("حدد شركة الاتصالات أولًا من تطبيقها الرسمي أو موقعها. وكيلك لا ينفذ الشحن أو تجديد الباقات مباشرة، ولا يطلب منك رقم البطاقة أو كلمة المرور.");
      return true;
    }

    if (/(قريب|قريبه|قريبة|اقرب|أقرب|مكاني|موقعي)/.test(text)) {
      const route = routes.find(item => item.terms.some(term => text.includes(normalize(term))));
      if (route) {
        const query = encodeURIComponent(route.map);
        addActionCard(route.message, "فتح البحث في الخرائط", `geo:0,0?q=${query}`);
        return true;
      }
    }

    const route = routes.find(item => item.terms.some(term => text.includes(normalize(term))));
    if (route) {
      const query = encodeURIComponent(route.map);
      addActionCard(route.message, "فتح البحث في الخرائط", `geo:0,0?q=${query}`);
      return true;
    }

    if (/(مهامي|المهام|التذكيرات)/.test(text)) {
      if (typeof originalView === "function") originalView("tasks");
      return true;
    }

    // Search the visible service catalogue before falling back to a clear explanation.
    const serviceButtons = Array.from(document.querySelectorAll("#home .service, #services .service"));
    const match = serviceButtons.find(button => {
      const label = normalize(button.innerText || button.textContent);
      return label && (label.includes(text) || text.includes(label));
    });
    if (match) {
      if (typeof originalView === "function") originalView("home");
      setTimeout(() => {
        match.scrollIntoView({ behavior: "smooth", block: "center" });
        match.classList.add("wakeel-search-hit");
        setTimeout(() => match.classList.remove("wakeel-search-hit"), 1800);
      }, 60);
      showResult("وجدت الخدمة الأقرب لطلبك في الصفحة الرئيسية. اضغط عليها لعرض الخيارات المتاحة.");
      return true;
    }

    showResult("لم أجد خدمة مطابقة بشكل موثوق. جرّب كتابة اسم الخدمة أو افتح تبويب «الخدمات» لاستعراض الأقسام. لا أريد أن أوهمك بأن معاملة مالية أو حكومية تمت دون تأكيد رسمي.");
    return true;
  }

  function loadTasks() {
    try {
      const value = JSON.parse(localStorage.getItem("wakeel.tasks.v1") || "[]");
      return Array.isArray(value) ? value.filter(task => task && typeof task.title === "string") : [];
    } catch (_) {
      return [];
    }
  }

  function saveTasks(tasks) {
    try {
      localStorage.setItem("wakeel.tasks.v1", JSON.stringify(tasks));
      return true;
    } catch (_) {
      notify("تعذر حفظ المهام. تحقق من مساحة التخزين المتاحة.");
      return false;
    }
  }

  function formatDue(value) {
    if (!value) return "بدون موعد محدد";
    const date = new Date(value);
    if (Number.isNaN(date.getTime())) return "موعد غير صالح";
    return new Intl.DateTimeFormat("ar-EG", {
      dateStyle: "medium", timeStyle: "short"
    }).format(date);
  }

  function renderTasks() {
    const list = $("#wakeelTaskList");
    const count = $("#wakeelTaskCount");
    if (!list) return;
    const tasks = loadTasks().sort((a, b) => {
      if (a.done !== b.done) return a.done ? 1 : -1;
      if (!a.due) return 1;
      if (!b.due) return -1;
      return new Date(a.due) - new Date(b.due);
    });
    list.replaceChildren();
    if (count) count.textContent = String(tasks.filter(task => !task.done).length);

    if (!tasks.length) {
      const empty = document.createElement("li");
      empty.className = "wakeel-task-empty";
      empty.textContent = "لا توجد مهام بعد. أضف أول مهمة من النموذج أعلاه.";
      list.appendChild(empty);
      return;
    }

    tasks.forEach(task => {
      const item = document.createElement("li");
      item.className = "wakeel-task-item" + (task.done ? " is-done" : "");
      const check = document.createElement("input");
      check.type = "checkbox";
      check.checked = !!task.done;
      check.setAttribute("aria-label", "تحديد المهمة كمكتملة");
      check.addEventListener("change", () => {
        const current = loadTasks();
        const target = current.find(entry => entry.id === task.id);
        if (target) target.done = check.checked;
        if (saveTasks(current)) renderTasks();
      });

      const details = document.createElement("div");
      details.className = "wakeel-task-details";
      const title = document.createElement("span");
      title.className = "wakeel-task-title";
      title.textContent = task.title;
      const due = document.createElement("small");
      due.textContent = formatDue(task.due);
      details.append(title, due);

      const remove = document.createElement("button");
      remove.type = "button";
      remove.className = "wakeel-task-delete";
      remove.textContent = "حذف";
      remove.addEventListener("click", () => {
        if (saveTasks(loadTasks().filter(entry => entry.id !== task.id))) renderTasks();
      });

      item.append(check, details, remove);
      list.appendChild(item);
    });
  }

  function checkDueTasks() {
    const now = Date.now();
    loadTasks().forEach(task => {
      if (task.done || !task.due) return;
      const due = new Date(task.due).getTime();
      if (!Number.isFinite(due) || due > now) return;
      const key = `wakeel.task.alerted.${task.id}`;
      try {
        if (sessionStorage.getItem(key)) return;
        sessionStorage.setItem(key, "1");
      } catch (_) {}
      notify(`موعد المهمة: ${task.title}`);
    });
  }

  function initTaskManager() {
    const section = $("#tasks .section");
    if (!section) return;
    section.className = "section wakeel-task-manager";
    section.innerHTML = `
      <div class="wakeel-task-heading">
        <div><h2>مهامي وتذكيراتي</h2><p>مهامك محفوظة على هذا الجهاز</p></div>
        <span class="wakeel-task-count" id="wakeelTaskCount">0</span>
      </div>
      <p class="wakeel-task-note">يمكنك تحديد موعد ومتابعة إنجاز المهمة. التذكير يظهر عند فتح التطبيق؛ لا توجد إشعارات أندرويد أو تنبيهات تعمل في الخلفية في هذه النسخة.</p>
      <form id="wakeelTaskForm" class="wakeel-task-form">
        <label class="wakeel-task-label" for="wakeelTaskTitle">اسم المهمة</label>
        <input id="wakeelTaskTitle" type="text" maxlength="100" placeholder="مثال: موعد الدواء" required>
        <label class="wakeel-task-label" for="wakeelTaskDue">الموعد (اختياري)</label>
        <input id="wakeelTaskDue" type="datetime-local">
        <button type="submit">إضافة المهمة</button>
      </form>
      <ul id="wakeelTaskList" class="wakeel-task-list"></ul>
    `;

    $("#wakeelTaskForm").addEventListener("submit", event => {
      event.preventDefault();
      const titleInput = $("#wakeelTaskTitle");
      const dueInput = $("#wakeelTaskDue");
      const title = titleInput.value.trim();
      if (!title) {
        titleInput.focus();
        return;
      }
      const tasks = loadTasks();
      tasks.push({
        id: `${Date.now()}-${Math.random().toString(36).slice(2, 8)}`,
        title,
        due: dueInput.value || "",
        done: false
      });
      if (saveTasks(tasks)) {
        event.currentTarget.reset();
        renderTasks();
        notify("تم حفظ المهمة على هذا الجهاز.");
        checkDueTasks();
      }
    });

    renderTasks();
    checkDueTasks();
  }

  function installStyles() {
    const style = document.createElement("style");
    style.textContent = `
      .wakeel-action-card { max-width:92%; }
      .wakeel-action-card p { margin:0 0 10px; line-height:1.8; }
      .wakeel-action-link { display:inline-flex; align-items:center; justify-content:center; padding:9px 14px; border-radius:12px; background:#1769f5; color:#fff; text-decoration:none; font-size:12px; font-weight:800; }
      .wakeel-search-hit { outline:2px solid #1769f5 !important; box-shadow:0 0 0 4px rgba(23,105,245,.16) !important; }
      .wakeel-task-heading { display:flex; align-items:center; justify-content:space-between; gap:12px; }
      .wakeel-task-heading h2 { margin:0 0 5px; font-size:16px; }
      .wakeel-task-heading p { margin:0; color:#7184a5; font-size:11px; }
      .wakeel-task-count { min-width:34px; height:34px; display:grid; place-items:center; border-radius:50%; background:#eaf2ff; color:#1769f5; font-weight:900; }
      .wakeel-task-note { margin:12px 0; color:#7184a5; font-size:11px; line-height:1.8; }
      .wakeel-task-form { display:grid; gap:8px; padding:13px; border:1px solid #e0eafa; border-radius:16px; background:#fff; }
      .wakeel-task-label { color:#45618d; font-size:11px; font-weight:800; }
      .wakeel-task-form input { width:100%; min-width:0; box-sizing:border-box; border:1px solid #dce8fa; border-radius:12px; padding:11px; background:#fff; color:#123878; font:inherit; font-size:12px; }
      .wakeel-task-form button { border:0; border-radius:12px; padding:12px; background:#1769f5; color:#fff; font-weight:800; }
      .wakeel-task-list { list-style:none; margin:13px 0 0; padding:0; display:grid; gap:8px; }
      .wakeel-task-item { display:flex; align-items:center; gap:9px; padding:11px; border:1px solid #e0eafa; border-radius:13px; background:#fff; }
      .wakeel-task-item input { width:18px; height:18px; flex:none; accent-color:#1769f5; }
      .wakeel-task-details { min-width:0; flex:1; display:grid; gap:5px; }
      .wakeel-task-title { color:#123878; font-size:12px; font-weight:800; overflow-wrap:anywhere; }
      .wakeel-task-details small { color:#7184a5; font-size:10px; }
      .wakeel-task-item.is-done .wakeel-task-title { text-decoration:line-through; opacity:.55; }
      .wakeel-task-delete { border:0; background:#fff0f2; color:#c8334e; border-radius:9px; padding:8px 10px; font-size:10px; }
      .wakeel-task-empty { padding:14px; border:1px dashed #dce8fa; border-radius:12px; color:#7184a5; text-align:center; font-size:11px; }
    `;
    document.head.appendChild(style);
  }

  function init() {
    installStyles();
    initTaskManager();

    // Home search and chat now share the same explicit service-routing logic.
    window.send = function () {
      const input = $("#input");
      const text = input ? input.value.trim() : "";
      if (!text) return;
      if (input) input.value = "";
      routeRequest(text);
    };
    window.sendComposer = function () {
      const input = $("#composerInput");
      const text = input ? input.value.trim() : "";
      if (!text) return;
      input.value = "";
      routeRequest(text);
    };
    window.quick = routeRequest;
    window.searchServices = routeRequest;

    document.addEventListener("visibilitychange", () => {
      if (!document.hidden) {
        renderTasks();
        checkDueTasks();
      }
    });
    window.setInterval(checkDueTasks, 60000);
  }

  init();
})();
