package com.agent.wakeel;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.os.Build;
import android.view.View;
import android.view.Window;
import android.view.WindowInsets;
import android.webkit.JavascriptInterface;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;

import androidx.webkit.WebViewAssetLoader;

public class MainActivity extends Activity {
    private static final String APP_URL = "https://appassets.androidplatform.net/assets/index.html";
    private WebView webView;

    @SuppressLint("SetJavaScriptEnabled")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        Window window = getWindow();
        window.setStatusBarColor(Color.rgb(248, 251, 255));
        window.setNavigationBarColor(Color.WHITE);
        window.getDecorView().setSystemUiVisibility(
                View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR | View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR
        );

        WebViewAssetLoader assetLoader = new WebViewAssetLoader.Builder()
                .addPathHandler("/assets/", new WebViewAssetLoader.AssetsPathHandler(this))
                .build();

        webView = new WebView(this);
        webView.setBackgroundColor(Color.rgb(246, 249, 253));
        webView.setOverScrollMode(View.OVER_SCROLL_NEVER);
        webView.setFitsSystemWindows(true);
        webView.setVerticalScrollBarEnabled(false);
        webView.setHorizontalScrollBarEnabled(false);
        // Apply Android system-bar insets to the WebView viewport. The HTML reserves
        // additional scroll space at the bottom so the last cards remain reachable.
        webView.setOnApplyWindowInsetsListener((view, insets) -> {
            int topInset;
            int bottomInset;
            int leftInset = 0;
            int rightInset = 0;
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                android.graphics.Insets bars = insets.getInsets(
                        WindowInsets.Type.statusBars()
                                | WindowInsets.Type.navigationBars()
                                | WindowInsets.Type.displayCutout());
                topInset = bars.top;
                bottomInset = bars.bottom;
                leftInset = bars.left;
                rightInset = bars.right;
            } else {
                topInset = insets.getSystemWindowInsetTop();
                bottomInset = insets.getSystemWindowInsetBottom();
                leftInset = insets.getSystemWindowInsetLeft();
                rightInset = insets.getSystemWindowInsetRight();
            }
            view.setPadding(leftInset, topInset, rightInset, bottomInset);
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                return WindowInsets.CONSUMED;
            }
            return insets;
        });
        webView.setWebViewClient(new WebViewClient() {
            @Override
            public WebResourceResponse shouldInterceptRequest(
                    WebView view, WebResourceRequest request) {
                return assetLoader.shouldInterceptRequest(request.getUrl());
            }

            @Override
            @SuppressWarnings("deprecation")
            public WebResourceResponse shouldInterceptRequest(WebView view, String url) {
                return assetLoader.shouldInterceptRequest(Uri.parse(url));
            }

            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                return !APP_URL.equals(request.getUrl().toString());
            }

            @Override
            @SuppressWarnings("deprecation")
            public boolean shouldOverrideUrlLoading(WebView view, String url) {
                return !APP_URL.equals(url);
            }
        });

        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setAllowFileAccess(false);
        settings.setAllowContentAccess(false);
        settings.setAllowFileAccessFromFileURLs(false);
        settings.setAllowUniversalAccessFromFileURLs(false);
        settings.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);
        settings.setMediaPlaybackRequiresUserGesture(true);
        settings.setBuiltInZoomControls(false);
        settings.setDisplayZoomControls(false);
        settings.setTextZoom(100);

        webView.addJavascriptInterface(new WakeelAndroidBridge(), "WakeelAndroid");
        webView.loadUrl(APP_URL);
        setContentView(webView);
        // Ensure Android dispatches status/navigation bar insets after the WebView is attached.
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT) {
            webView.requestApplyInsets();
        }
    }

    /** Opens the Android health-data hub so compatible watch companion apps can be managed. */
    private final class WakeelAndroidBridge {
        @JavascriptInterface
        public void openHealthConnectSettings() {
            runOnUiThread(() -> {
                // Android 14+ provides Health Connect as a system settings surface.
                if (Build.VERSION.SDK_INT >= 34) {
                    try {
                        startActivity(new Intent("android.health.connect.action.HEALTH_HOME_SETTINGS"));
                        return;
                    } catch (ActivityNotFoundException ignored) {
                        // Fall through to the backward-compatible Health Connect action.
                    }
                }

                try {
                    startActivity(new Intent("androidx.health.ACTION_HEALTH_CONNECT_SETTINGS"));
                    return;
                } catch (ActivityNotFoundException ignored) {
                    // The standalone Health Connect app may not be installed on Android 13 or lower.
                }

                Intent healthApp = getPackageManager().getLaunchIntentForPackage("com.google.android.apps.healthdata");
                if (healthApp != null) {
                    try {
                        startActivity(healthApp);
                        return;
                    } catch (ActivityNotFoundException ignored) {
                        // Try the store below.
                    }
                }

                try {
                    startActivity(new Intent(Intent.ACTION_VIEW,
                            Uri.parse("market://details?id=com.google.android.apps.healthdata")));
                } catch (ActivityNotFoundException ignored) {
                    Toast.makeText(MainActivity.this,
                            "ابحث عن Health Connect في متجر Google Play أو إعدادات الخصوصية.",
                            Toast.LENGTH_LONG).show();
                }
            });
        }
    }

    @Override
    public void onBackPressed() {
        if (webView != null) {
            webView.evaluateJavascript("(window.androidBack && window.androidBack())", value -> {
                if ("false".equals(value)) {
                    MainActivity.this.finish();
                }
            });
        } else {
            super.onBackPressed();
        }
    }

    @Override
    protected void onDestroy() {
        if (webView != null) {
            webView.stopLoading();
            webView.setWebViewClient(null);
            webView.destroy();
            webView = null;
        }
        super.onDestroy();
    }
}
